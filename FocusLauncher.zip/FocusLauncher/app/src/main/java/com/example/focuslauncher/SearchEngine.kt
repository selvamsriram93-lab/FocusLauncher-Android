package com.example.focuslauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Patterns
import java.net.URLEncoder

/** Where the home search bar and drawer "Search the web" send your query. */
enum class SearchEngine(val label: String, private val base: String) {
    Google("Google", "https://www.google.com/search?q="),
    DuckDuckGo("DuckDuckGo", "https://duckduckgo.com/?q="),
    Bing("Bing", "https://www.bing.com/search?q="),
    Brave("Brave", "https://search.brave.com/search?q=");

    fun url(query: String) = base + URLEncoder.encode(query, "UTF-8")
}

object WebSearch {
    /** Opens a web address directly if it looks like one, otherwise searches. */
    fun open(ctx: Context, engine: SearchEngine, query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val isAddress = !q.contains(' ') && Patterns.WEB_URL.matcher(q).matches()
        val url = when {
            isAddress && (q.startsWith("http://") || q.startsWith("https://")) -> q
            isAddress -> "https://$q"
            else -> engine.url(q)
        }
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
