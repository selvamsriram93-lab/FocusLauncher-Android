package com.example.focuslauncher

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Declared with android:showWhenLocked="true" so it can display above the lock screen. */
class LockCardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        enableEdgeToEdge()

        val prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val theme = runCatching { LauncherTheme.valueOf(prefs.getString("theme", "")!!) }
            .getOrDefault(LauncherTheme.Midnight)
        val note = prefs.getString("note", "") ?: ""
        val font = runCatching { LauncherFont.valueOf(prefs.getString("font", "")!!) }
            .getOrDefault(LauncherFont.Default)

        setContent {
          ProvideTextStyle(TextStyle(fontFamily = font.family)) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(theme.top, theme.bottom)))
                    .systemBarsPadding()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("Lock screen card", color = theme.accent, fontSize = 14.sp)
                Spacer(Modifier.height(24.dp))
                Text(note, color = theme.text, fontSize = 26.sp, textAlign = TextAlign.Center, lineHeight = 36.sp)
                Spacer(Modifier.height(40.dp))
                Button(
                    onClick = { finish() },
                    colors = ButtonDefaults.buttonColors(containerColor = theme.accent, contentColor = theme.top),
                ) { Text("Close") }
            }
          }
        }
    }
}
