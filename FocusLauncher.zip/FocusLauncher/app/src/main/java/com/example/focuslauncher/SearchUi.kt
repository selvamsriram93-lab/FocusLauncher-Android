package com.example.focuslauncher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

/** Extra results above the app list: calculator and web search. */
@Composable
fun SearchExtras(vm: LauncherViewModel, onClose: () -> Unit) {
    val q = vm.query.trim()
    if (q.isEmpty()) return
    val ctx = LocalContext.current
    val t = vm.theme

    val calc = remember(q) { Calc.eval(q) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        calc?.let { v ->
            val text = Calc.format(v)
            ResultRow(t, "= $text", "Tap to copy") {
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("result", text))
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        ResultRow(t, "Search ${vm.searchEngine.label} for \u201C$q\u201D", "Opens your browser") {
            WebSearch.open(ctx, vm.searchEngine, q)
            onClose()
        }
    }
}

@Composable
private fun ResultRow(t: LauncherTheme, title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(t.text.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(title, color = t.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = t.accent, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
