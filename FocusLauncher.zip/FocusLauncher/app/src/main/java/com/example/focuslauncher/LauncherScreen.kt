package com.example.focuslauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

private fun openAppInfo(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

@Composable
fun LauncherScreen(vm: LauncherViewModel) {
    // Apply the chosen font to every Text (dialogs included)
    ProvideTextStyle(TextStyle(fontFamily = vm.font.family)) { LauncherContent(vm) }
}

@Composable
private fun LauncherContent(vm: LauncherViewModel) {
    val t = vm.theme
    var drawerOpen by remember { mutableStateOf(false) }
    var showThemes by remember { mutableStateOf(false) }
    var showFocus by remember { mutableStateOf(false) }

    // keeps Focus mode timing and the clock fresh
    LaunchedEffect(Unit) { while (true) { vm.tick(); delay(20_000) } }

    // Back does nothing on the home screen; closes the drawer if open
    BackHandler(enabled = true) {
        if (drawerOpen) { drawerOpen = false; vm.query = "" }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(t.top, t.bottom)))
            .systemBarsPadding()
    ) {
        if (drawerOpen) {
            AppDrawer(vm, onClose = { drawerOpen = false; vm.query = "" })
        } else {
            HomeScreen(
                vm,
                onOpenDrawer = { drawerOpen = true },
                onLongPressBackground = { showThemes = true },
                onOpenFocus = { showFocus = true },
            )
        }
        if (!vm.welcomeDone) WelcomeScreen(t) { vm.welcomeDone = true }
    }

    if (showThemes) LauncherSettings(vm) { showThemes = false }
    if (showFocus) FocusDialog(vm) { showFocus = false }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeScreen(
    vm: LauncherViewModel,
    onOpenDrawer: () -> Unit,
    onLongPressBackground: () -> Unit,
    onOpenFocus: () -> Unit,
) {
    val t = vm.theme
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { now = LocalDateTime.now(); delay(15_000) }
    }
    var pickerFor by remember { mutableStateOf<Int?>(null) }
    var menuFor by remember { mutableStateOf<Int?>(null) }
    var colorFor by remember { mutableStateOf<Int?>(null) }
    val pagerState = rememberPagerState(pageCount = { PAGES })

    Column(
        Modifier
            .fillMaxSize()
            // swipe up = app drawer, swipe down = notifications
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -120f) onOpenDrawer()
                    },
                ) { _, dy -> total += dy }
            }
            // Long-press opens launcher settings.
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { onLongPressBackground() })
            }
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        // swipe left/right between the two home pages
        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
            Column(Modifier.fillMaxSize()) {
                // Top 30%
                Box(Modifier.weight(3f).fillMaxWidth()) {
                    if (page == 0) {
                        Column(Modifier.fillMaxSize()) {
                            Box(Modifier.weight(1f).fillMaxWidth()) { ClockWidget(vm.clockStyle, now, t) }
                            InfoStrip(vm, onOpenFocus)
                        }
                    } else {
                        InfoCards(vm, t)
                    }
                }
                // Bottom 70%: 10 quick-access slots for this page
                Box(Modifier.weight(7f).fillMaxWidth()) {
                    SlotGrid(vm, page, onEmpty = { pickerFor = it }, onMenu = { menuFor = it })
                }
            }
        }

        if (vm.showSearchBar) HomeSearchBar(vm)

        Column(Modifier.align(Alignment.CenterHorizontally), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.padding(top = 4.dp)) {
                repeat(PAGES) { i ->
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (pagerState.currentPage == i) t.accent else t.text.copy(alpha = 0.3f))
                    )
                }
            }
            Text(
                "All apps \u2191",
                color = t.accent, fontSize = 14.sp,
                modifier = Modifier.clickable { onOpenDrawer() }.padding(10.dp),
            )
        }
    }

    pickerFor?.let { slot -> AppPickerDialog(vm, slot) { pickerFor = null } }
    menuFor?.let { slot ->
        val label = vm.apps.firstOrNull { it.packageName == vm.slots[slot] }?.label ?: "Slot ${slot + 1}"
        SlotMenuDialog(
            label = label,
            onReplace = { pickerFor = slot; menuFor = null },
            onColor = { colorFor = slot; menuFor = null },
            onRemove = { vm.setSlot(slot, null); menuFor = null },
            onDismiss = { menuFor = null },
        )
    }
    colorFor?.let { slot ->
        vm.apps.firstOrNull { it.packageName == vm.slots[slot] }?.let { app ->
            ColorPickerDialog(vm, app) { colorFor = null }
        }
    }
}

@Composable
private fun SlotGrid(
    vm: LauncherViewModel,
    page: Int,
    onEmpty: (Int) -> Unit,
    onMenu: (Int) -> Unit,
) {
    val t = vm.theme
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        for (row in 0 until MAX_SLOTS / 2) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (col in 0 until 2) {
                    val index = page * MAX_SLOTS + row * 2 + col
                    val pkg = vm.slots[index]
                    val app = pkg?.let { p -> vm.apps.firstOrNull { it.packageName == p } }
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        when {
                            app == null -> EmptySlot(t, vm.shape) { onEmpty(index) }
                            vm.isHidden(app.packageName) -> FocusLockedTile(
                                label = app.label, theme = t, iconShape = vm.shape,
                                onLongClick = { onMenu(index) },
                            ) {
                                Toast.makeText(ctx, "Focus mode is on ${vm.focusUntilText()}", Toast.LENGTH_SHORT).show()
                            }
                            else -> AppTile(
                                app = app,
                                theme = t,
                                unread = BadgeStore.counts[app.packageName] ?: 0,
                                usage = vm.usage[app.packageName],
                                colorful = vm.colorTiles,
                                shape = vm.shape,
                                colorOverride = vm.tileColors[app.packageName]?.let { Color(it) },
                                onClick = { launchApp(ctx, app.packageName) },
                                onLongClick = { onMenu(index) },
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppDrawer(vm: LauncherViewModel, onClose: () -> Unit) {
    val t = vm.theme
    val ctx = LocalContext.current
    var menuFor by remember { mutableStateOf<AppInfo?>(null) }
    var colorFor by remember { mutableStateOf<AppInfo?>(null) }
    val filtered = remember(vm.apps, vm.query, vm.focusOn, vm.blocked) {
        vm.apps.filter {
            it.label.contains(vm.query, ignoreCase = true) && !vm.isHidden(it.packageName)
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            placeholder = { Text("Search apps") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = t.text, unfocusedTextColor = t.text,
                focusedBorderColor = t.accent, unfocusedBorderColor = t.text.copy(alpha = 0.3f),
                cursorColor = t.accent,
            ),
        )
        SearchExtras(vm, onClose)
        if (vm.tiles) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize().padding(top = 8.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    AppTile(
                        app = app,
                        theme = t,
                        unread = BadgeStore.counts[app.packageName] ?: 0,
                        usage = vm.usage[app.packageName],
                        colorful = vm.colorTiles,
                        shape = vm.shape,
                        colorOverride = vm.tileColors[app.packageName]?.let { Color(it) },
                        onClick = { launchApp(ctx, app.packageName); onClose() },
                        onLongClick = { menuFor = app },
                        modifier = Modifier.height(104.dp),
                    )
                }
            }
        } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize().padding(top = 12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            items(filtered, key = { it.packageName }) { app ->
                val raw = remember(app.packageName) { app.icon.toBitmap(128, 128) }
                val bmp = remember(raw) { raw.asImageBitmap() }
                val auto = remember(app.packageName) { TileColors.forApp(app.packageName, raw) }
                val back = vm.tileColors[app.packageName]?.let { Color(it) } ?: auto
                Column(
                    Modifier
                        .combinedClickable(
                            onClick = { launchApp(ctx, app.packageName); onClose() },
                            onLongClick = { menuFor = app },
                        )
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val unread = BadgeStore.counts[app.packageName] ?: 0
                    Box(Modifier.size(52.dp)) {
                        Box(
                            Modifier.fillMaxSize().clip(vm.shape.chip()).background(back),
                            contentAlignment = Alignment.Center,
                        ) { Image(bmp, app.label, Modifier.size(38.dp)) }
                        if (unread > 0) {
                            Badge(unread, Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-4).dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        app.label, color = t.text, fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    )
                }
            }
        }
        }
    }

    menuFor?.let { app ->
        val pinned = app.packageName in vm.favorites
        AlertDialog(
            onDismissRequest = { menuFor = null },
            confirmButton = {},
            title = { Text(app.label) },
            text = {
                Column {
                    TextButton(onClick = {
                        if (!vm.toggleFavorite(app.packageName)) {
                            Toast.makeText(ctx, "Home is full (20 apps). Remove one first.", Toast.LENGTH_SHORT).show()
                        }
                        menuFor = null
                    }) {
                        Text(if (pinned) "Unpin from home" else "Pin to home")
                    }
                    TextButton(onClick = { colorFor = app; menuFor = null }) { Text("Tile colour") }
                    TextButton(onClick = { openAppInfo(ctx, app.packageName); menuFor = null }) {
                        Text("App info / Uninstall")
                    }
                }
            },
        )
    }

    colorFor?.let { app -> ColorPickerDialog(vm, app) { colorFor = null } }
}
