package com.example.focuslauncher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Weather(val temp: Int, val code: Int, val high: Int, val low: Int, val city: String = "")

data class GeoHit(val name: String, val lat: Double, val lon: Double)

/** Free, key-less weather from open-meteo.com. Only the city name you type is sent. */
object WeatherApi {

    private fun get(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.inputStream.bufferedReader().use { it.readText() }
    }.getOrNull()

    fun geocode(name: String): GeoHit? {
        val body = get(
            "https://geocoding-api.open-meteo.com/v1/search?name=" +
                URLEncoder.encode(name, "UTF-8") + "&count=1&language=en&format=json"
        ) ?: return null
        return runCatching {
            val r = JSONObject(body).getJSONArray("results").getJSONObject(0)
            GeoHit(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
        }.getOrNull()
    }

    fun fetch(lat: Double, lon: Double, fahrenheit: Boolean): Weather? {
        val unit = if (fahrenheit) "fahrenheit" else "celsius"
        val body = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code" +
                "&daily=temperature_2m_max,temperature_2m_min" +
                "&timezone=auto&forecast_days=1&temperature_unit=$unit"
        ) ?: return null
        return runCatching {
            val j = JSONObject(body)
            val cur = j.getJSONObject("current")
            val day = j.getJSONObject("daily")
            Weather(
                temp = Math.round(cur.getDouble("temperature_2m")).toInt(),
                code = cur.getInt("weather_code"),
                high = Math.round(day.getJSONArray("temperature_2m_max").getDouble(0)).toInt(),
                low = Math.round(day.getJSONArray("temperature_2m_min").getDouble(0)).toInt(),
            )
        }.getOrNull()
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow showers"
        in 95..99 -> "Thunderstorm"
        else -> "Weather"
    }
}
