package com.example.focuslauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

/**
 * App tile. [colorful] = each app gets its own colour (taken from its icon);
 * otherwise a calm theme-tinted tile with a grey icon.
 * Shows: icon top-left, unread bubble top-right, name bottom-left, usage % bottom-right.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppTile(
    app: AppInfo,
    theme: LauncherTheme,
    unread: Int,
    usage: Int?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    colorful: Boolean = true,
    colorOverride: Color? = null,
    shape: IconShape = IconShape.Rounded,
) {
    val bmp = remember(app.packageName) { app.icon.toBitmap(96, 96) }
    val img = remember(bmp) { bmp.asImageBitmap() }
    val autoColor = remember(app.packageName) { TileColors.forApp(app.packageName, bmp) }
    val tileColor = colorOverride ?: autoColor
    val grey = remember { ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) }

    val bg = if (colorful) tileColor
    else theme.text.copy(alpha = if (unread > 0) 0.14f else 0.07f)
    val fg = if (colorful) Color.White else theme.text
    val bubble = if (colorful) Color.White else theme.accent

    Box(
        modifier
            .padding(5.dp)
            .clip(shape.tile())
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(shape.pad)
    ) {
        if (colorful) {
            Box(
                Modifier
                    .size(26.dp)
                    .align(Alignment.TopStart)
                    .clip(shape.chip())
                    .background(Color.White.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center,
            ) { Image(img, null, Modifier.size(20.dp)) }
        } else {
            Image(
                img, null,
                Modifier.size(20.dp).align(Alignment.TopStart).clip(shape.chip()),
                colorFilter = grey, alpha = 0.8f,
            )
        }

        if (unread > 0) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .border(1.5.dp, bubble, RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    if (unread > 99) "99+" else unread.toString(),
                    color = bubble, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                )
            }
        }

        Text(
            app.label,
            color = fg, fontSize = 15.sp,
            fontWeight = if (unread > 0) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth(0.7f),
        )
        if (usage != null) {
            Text(
                "%02d%%".format(usage),
                color = fg.copy(alpha = if (colorful) 0.7f else 0.4f), fontSize = 13.sp,
                modifier = Modifier.align(Alignment.BottomEnd),
            )
        }
    }
}
