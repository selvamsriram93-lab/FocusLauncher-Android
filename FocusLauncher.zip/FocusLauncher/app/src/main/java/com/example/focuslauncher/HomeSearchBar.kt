package com.example.focuslauncher

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pill-shaped search bar for the bottom of the home screen. Tap, type, press search. */
@Composable
fun HomeSearchBar(vm: LauncherViewModel) {
    val t = vm.theme
    val ctx = LocalContext.current
    val focusManager = LocalFocusManager.current
    var editing by remember { mutableStateOf(false) }
    var hadFocus by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val pill = RoundedCornerShape(24.dp)

    fun go() {
        val q = text.trim()
        if (q.isNotEmpty()) WebSearch.open(ctx, vm.searchEngine, q)
        text = ""
        editing = false
        focusManager.clearFocus()
    }

    Row(
        Modifier
            .fillMaxWidth()
            .imePadding()
            .padding(horizontal = 5.dp, vertical = 4.dp)
            .height(46.dp)
            .clip(pill)
            .background(t.text.copy(alpha = 0.1f))
            .border(1.dp, t.text.copy(alpha = 0.12f), pill)
            .clickable(enabled = !editing) { editing = true }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SearchGlyph(t.text.copy(alpha = 0.8f), Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))

        if (editing) {
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(color = t.text, fontSize = 16.sp),
                cursorBrush = SolidColor(t.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { go() }),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus)
                    .onFocusChanged {
                        if (it.isFocused) hadFocus = true
                        else if (hadFocus) { hadFocus = false; editing = false }
                    },
            )
            LaunchedEffect(Unit) { focus.requestFocus() }
            if (text.isNotEmpty()) {
                Text(
                    "\u2715", color = t.text.copy(alpha = 0.7f), fontSize = 16.sp,
                    modifier = Modifier.clickable { text = "" }.padding(horizontal = 8.dp),
                )
            }
        } else {
            Text(
                "Search ${vm.searchEngine.label}",
                color = t.text.copy(alpha = 0.6f), fontSize = 16.sp,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.width(8.dp))
        MicGlyph(
            t.text.copy(alpha = 0.8f),
            Modifier
                .size(20.dp)
                .clickable {
                    runCatching {
                        ctx.startActivity(
                            Intent(RecognizerIntent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }.onFailure {
                        Toast.makeText(ctx, "Voice search isn't available on this phone", Toast.LENGTH_SHORT).show()
                    }
                },
        )
    }
}

@Composable
private fun SearchGlyph(color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val r = size.minDimension * 0.34f
        val c = Offset(size.width * 0.42f, size.height * 0.42f)
        drawCircle(color, r, c, style = Stroke(2.dp.toPx()))
        drawLine(
            color,
            Offset(c.x + r * 0.72f, c.y + r * 0.72f),
            Offset(size.width * 0.95f, size.height * 0.95f),
            strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
        )
    }
}

@Composable
private fun MicGlyph(color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            color, Offset(w * 0.34f, 0f), Size(w * 0.32f, h * 0.6f),
            cornerRadius = CornerRadius(w * 0.16f),
        )
        drawArc(
            color, 0f, 180f, false,
            topLeft = Offset(w * 0.18f, h * 0.25f), size = Size(w * 0.64f, h * 0.5f),
            style = Stroke(1.8.dp.toPx()),
        )
        drawLine(color, Offset(w * 0.5f, h * 0.75f), Offset(w * 0.5f, h * 0.95f), 1.8.dp.toPx(), StrokeCap.Round)
    }
}
