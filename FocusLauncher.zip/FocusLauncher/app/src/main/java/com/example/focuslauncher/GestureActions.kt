package com.example.focuslauncher

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

object GestureActions {

    private fun admin(ctx: Context) = ComponentName(ctx, LockAdminReceiver::class.java)
    private fun dpm(ctx: Context) = ctx.getSystemService(DevicePolicyManager::class.java)

    fun isLockEnabled(ctx: Context) = dpm(ctx).isAdminActive(admin(ctx))

    /** Double-tap: locks the screen (only if the user enabled it in Settings). */
    fun lockScreen(ctx: Context): Boolean {
        if (!isLockEnabled(ctx)) return false
        dpm(ctx).lockNow()
        return true
    }

    /** Turns double-tap-to-lock on (asks Android for permission) or off. */
    fun toggleLockAdmin(ctx: Context) {
        if (isLockEnabled(ctx)) {
            dpm(ctx).removeActiveAdmin(admin(ctx))
            Toast.makeText(ctx, "Double-tap to lock is off", Toast.LENGTH_SHORT).show()
        } else {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin(ctx))
                    .putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Lets double-tapping the home screen lock your phone. Nothing else is controlled.",
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Swipe down: pulls down the notification shade. Uses a hidden Android call, so it may not work on every phone. */
    @SuppressLint("WrongConstant")
    fun expandNotifications(ctx: Context): Boolean = runCatching {
        val bar = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(bar)
        true
    }.getOrDefault(false)
}
