package com.example.focuslauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun unit(vm: LauncherViewModel) = if (vm.useFahrenheit) "F" else "C"

/** One line under the clock: weather, battery and the Focus chip. */
@Composable
fun InfoStrip(vm: LauncherViewModel, onFocus: () -> Unit) {
    val t = vm.theme
    val battery = rememberBattery()
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        vm.weather?.let { w ->
            Text(
                "${w.temp}\u00B0${unit(vm)} ${WeatherApi.describe(w.code)}",
                color = t.text.copy(alpha = 0.85f), fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
        }
        BatteryChip(battery, t)
        Spacer(Modifier.weight(1f))
        val on = vm.focusOn
        Text(
            if (on) "Focus ${vm.focusUntilShort()}" else "Focus",
            color = if (on) t.accent else t.text.copy(alpha = 0.55f),
            fontSize = 12.sp,
            modifier = Modifier
                .border(1.dp, if (on) t.accent else t.text.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                .clickable(onClick = onFocus)
                .padding(horizontal = 9.dp, vertical = 3.dp),
        )
    }
}

@Composable
private fun BatteryChip(b: BatteryInfo, t: LauncherTheme) {
    val low = b.level <= 15 && !b.charging
    val fill = if (low) Color(0xFFEF4444) else t.accent
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(22.dp, 11.dp)
                .border(1.5.dp, t.text.copy(alpha = 0.7f), RoundedCornerShape(3.dp))
                .padding(1.5.dp)
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(b.level / 100f)
                    .clip(RoundedCornerShape(1.dp))
                    .background(fill)
            )
        }
        Spacer(Modifier.width(5.dp))
        Text(
            "${b.level}%" + if (b.charging) " \u26A1" else "",
            color = t.text.copy(alpha = 0.85f), fontSize = 13.sp,
        )
    }
}

/** Page 2 header: big weather and battery cards. */
@Composable
fun InfoCards(vm: LauncherViewModel, t: LauncherTheme) {
    val battery = rememberBattery()
    Row(
        Modifier.fillMaxSize().padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(
            Modifier
                .weight(1f).fillMaxHeight()
                .clip(vm.shape.tile())
                .background(t.text.copy(alpha = 0.07f))
                .padding(vm.shape.pad),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Weather", color = t.accent, fontSize = 12.sp)
            val w = vm.weather
            if (w != null) {
                Text("${w.temp}\u00B0", color = t.text, fontSize = 38.sp, fontWeight = FontWeight.Light)
                Column {
                    Text(WeatherApi.describe(w.code), color = t.text, fontSize = 13.sp, maxLines = 1)
                    Text("H ${w.high}\u00B0  L ${w.low}\u00B0 \u00B7 ${vm.city}", color = t.text.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                Text("--", color = t.text, fontSize = 38.sp, fontWeight = FontWeight.Light)
                Text(
                    if (vm.city.isEmpty()) "Set a city in Settings" else "Loading\u2026",
                    color = t.text.copy(alpha = 0.6f), fontSize = 12.sp,
                )
            }
        }
        Column(
            Modifier
                .weight(1f).fillMaxHeight()
                .clip(vm.shape.tile())
                .background(t.text.copy(alpha = 0.07f))
                .padding(vm.shape.pad),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Battery", color = t.accent, fontSize = 12.sp)
            Text("${battery.level}%", color = t.text, fontSize = 38.sp, fontWeight = FontWeight.Light)
            Column {
                Box(
                    Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        .background(t.text.copy(alpha = 0.15f))
                ) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(battery.level / 100f)
                            .background(if (battery.level <= 15 && !battery.charging) Color(0xFFEF4444) else t.accent)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(if (battery.charging) "Charging" else "On battery", color = t.text.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        }
    }
}
