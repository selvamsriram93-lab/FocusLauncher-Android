package com.example.focuslauncher

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

/**
 * Picks a tile colour for each app: the most vivid colour found in its icon
 * (WhatsApp -> green, Gmail -> red, ...). Greyscale icons get a stable colour
 * from the fallback palette, so every app keeps the same colour every time.
 */
object TileColors {

    /** Colours offered in the colour picker (first 8 also used as the automatic fallback). */
    val PALETTE = listOf(
        0xFF16A34A, 0xFF2563EB, 0xFF7C3AED, 0xFFDC2626,
        0xFF0D9488, 0xFFD97706, 0xFFDB2777, 0xFF475569,
        0xFFEA580C, 0xFF0891B2, 0xFF65A30D, 0xFF4F46E5,
    ).map { Color(it) }

    private val FALLBACK = PALETTE.take(8)

    fun forApp(pkg: String, icon: Bitmap): Color {
        val small = Bitmap.createScaledBitmap(icon, 24, 24, true)
        val buckets = 12
        val weight = FloatArray(buckets)
        val sumR = FloatArray(buckets)
        val sumG = FloatArray(buckets)
        val sumB = FloatArray(buckets)
        val hsv = FloatArray(3)

        for (y in 0 until small.height) for (x in 0 until small.width) {
            val px = small.getPixel(x, y)
            if (AColor.alpha(px) < 200) continue
            AColor.colorToHSV(px, hsv)
            if (hsv[1] < 0.3f || hsv[2] < 0.3f) continue // skip white / grey / black
            val b = ((hsv[0] / 360f) * buckets).toInt().coerceIn(0, buckets - 1)
            val w = hsv[1] * hsv[2]
            weight[b] += w
            sumR[b] += AColor.red(px) * w
            sumG[b] += AColor.green(px) * w
            sumB[b] += AColor.blue(px) * w
        }

        val best = weight.indices.maxByOrNull { weight[it] } ?: 0
        if (weight[best] < 1.5f) { // no vivid colour in the icon
            return FALLBACK[abs(pkg.hashCode()) % FALLBACK.size]
        }

        val rgb = AColor.rgb(
            (sumR[best] / weight[best]).toInt(),
            (sumG[best] / weight[best]).toInt(),
            (sumB[best] / weight[best]).toInt(),
        )
        // Keep it vivid but dark enough for white text
        AColor.colorToHSV(rgb, hsv)
        hsv[1] = hsv[1].coerceIn(0.55f, 0.9f)
        hsv[2] = hsv[2].coerceIn(0.45f, 0.78f)
        return Color(AColor.HSVToColor(hsv))
    }
}
