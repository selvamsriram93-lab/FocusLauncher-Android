package com.example.focuslauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

/** An empty quick-access slot: tap the "+" to choose an app. */
@Composable
fun EmptySlot(theme: LauncherTheme, iconShape: IconShape, onClick: () -> Unit) {
    val shape = iconShape.tile()
    Box(
        Modifier
            .fillMaxSize()
            .padding(5.dp)
            .clip(shape)
            .border(1.dp, theme.text.copy(alpha = 0.15f), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("+", color = theme.accent.copy(alpha = 0.7f), fontSize = 30.sp, fontWeight = FontWeight.Light)
    }
}

/** Searchable list of installed apps; choosing one puts it in [slot]. */
@Composable
fun AppPickerDialog(vm: LauncherViewModel, slot: Int, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val choices = vm.apps.filter {
        it.packageName !in vm.favorites && it.label.contains(q, ignoreCase = true)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Choose app for slot ${slot + 1}") },
        text = {
            Column {
                OutlinedTextField(
                    value = q, onValueChange = { q = it },
                    singleLine = true, placeholder = { Text("Search") },
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(choices, key = { it.packageName }) { app ->
                        val bmp = remember(app.packageName) { app.icon.toBitmap(96, 96).asImageBitmap() }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.setSlot(slot, app.packageName); onDismiss() }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(bmp, app.label, Modifier.size(36.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(app.label)
                        }
                    }
                }
            }
        },
    )
}

/** Long-press menu for a filled slot. */
@Composable
fun SlotMenuDialog(
    label: String,
    onReplace: () -> Unit,
    onColor: () -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(label) },
        text = {
            Column {
                TextButton(onClick = onReplace) { Text("Replace app") }
                TextButton(onClick = onColor) { Text("Change colour") }
                TextButton(onClick = onRemove) { Text("Remove from home") }
            }
        },
    )
}

/** Pick a colour for one app's tile, or go back to automatic. */
@Composable
fun ColorPickerDialog(vm: LauncherViewModel, app: AppInfo, onDismiss: () -> Unit) {
    val current = vm.tileColors[app.packageName]
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        dismissButton = {
            TextButton(onClick = { vm.setTileColor(app.packageName, null); onDismiss() }) {
                Text("Auto (from icon)")
            }
        },
        title = { Text("${app.label} colour") },
        text = {
            Column {
                TileColors.PALETTE.chunked(4).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        row.forEach { c ->
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .clickable {
                                        vm.setColorTiles(true) // colours only show in colourful mode
                                        vm.setTileColor(app.packageName, c.toArgb())
                                        onDismiss()
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (current == c.toArgb()) {
                                    Text("\u2713", color = Color.White, fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }
            }
        },
    )
}

/** Shown instead of a distracting app while Focus mode is on. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusLockedTile(
    label: String,
    theme: LauncherTheme,
    iconShape: IconShape,
    onLongClick: () -> Unit,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .fillMaxSize()
            .padding(5.dp)
            .clip(iconShape.tile())
            .background(theme.text.copy(alpha = 0.05f))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(iconShape.pad)
    ) {
        Text("Focus", color = theme.accent.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.align(Alignment.TopStart))
        Text(
            label, color = theme.text.copy(alpha = 0.3f), fontSize = 15.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart),
        )
    }
}
