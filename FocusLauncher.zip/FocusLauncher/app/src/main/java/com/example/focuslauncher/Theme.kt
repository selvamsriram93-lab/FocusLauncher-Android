package com.example.focuslauncher

import androidx.compose.ui.graphics.Color

/** Add your own themes here. This is the main place to customize the look. */
enum class LauncherTheme(
    val label: String,
    val top: Color,
    val bottom: Color,
    val accent: Color,
    val text: Color,
) {
    Midnight("Midnight", Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF38BDF8), Color.White),
    Forest("Forest", Color(0xFF052E16), Color(0xFF14532D), Color(0xFF86EFAC), Color(0xFFF0FDF4)),
    Sunset("Sunset", Color(0xFF3B0764), Color(0xFF9A3412), Color(0xFFFDBA74), Color(0xFFFFF7ED)),
    Paper("Paper", Color(0xFFFAF7F2), Color(0xFFEDE6DA), Color(0xFFB45309), Color(0xFF1C1917)),
}
