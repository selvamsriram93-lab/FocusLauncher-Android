package com.example.focuslauncher

import android.app.admin.DeviceAdminReceiver

/** Only used for the "force-lock" policy so double-tap can lock the screen. */
class LockAdminReceiver : DeviceAdminReceiver()
