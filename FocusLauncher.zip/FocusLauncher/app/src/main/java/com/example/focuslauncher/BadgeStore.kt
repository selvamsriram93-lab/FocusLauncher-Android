package com.example.focuslauncher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Unread-notification count per package. Compose reads this and redraws badges automatically. */
object BadgeStore {
    var counts by mutableStateOf<Map<String, Int>>(emptyMap())
}
