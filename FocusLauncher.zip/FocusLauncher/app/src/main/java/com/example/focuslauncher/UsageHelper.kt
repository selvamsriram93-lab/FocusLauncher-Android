package com.example.focuslauncher

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

/** Each app's share (%) of today's total screen time. Needs "Usage access" permission. */
object UsageHelper {

    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName,
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun todayShare(ctx: Context, packages: Set<String>): Map<String, Int> {
        if (!hasAccess(ctx)) return emptyMap()
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis())
            ?: return emptyMap()
        val ms = stats.filter { it.packageName in packages }
            .groupBy { it.packageName }
            .mapValues { (_, l) -> l.sumOf { it.totalTimeInForeground } }
            .filterValues { it > 0 }
        val total = ms.values.sum()
        if (total <= 0) return emptyMap()
        return ms.mapValues { (it.value * 100f / total).roundToInt() }
    }
}
