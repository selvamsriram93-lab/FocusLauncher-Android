package com.example.focuslauncher

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Shapes you can switch between in Settings when you feel like a change.
 * [tile] is the outline of a whole tile, [chip] is for the small icon holder
 * (also used for icons in the classic grid), [pad] keeps text clear of curved corners.
 */
enum class IconShape(val label: String, val pad: Dp) {
    Rounded("Rounded", 12.dp),
    Squircle("Soft squircle", 14.dp),
    Round("Extra round / circle", 20.dp),
    Square("Sharp square", 12.dp),
    Cut("Cut corners", 14.dp),
    Leaf("Leaf", 16.dp);

    fun tile(): Shape = when (this) {
        Rounded -> RoundedCornerShape(18.dp)
        Squircle -> RoundedCornerShape(30)
        Round -> RoundedCornerShape(40)
        Square -> RoundedCornerShape(3.dp)
        Cut -> CutCornerShape(16.dp)
        Leaf -> RoundedCornerShape(topStart = 28.dp, topEnd = 4.dp, bottomEnd = 28.dp, bottomStart = 4.dp)
    }

    fun chip(): Shape = when (this) {
        Rounded -> RoundedCornerShape(28)
        Squircle -> RoundedCornerShape(40)
        Round -> CircleShape
        Square -> RoundedCornerShape(4)
        Cut -> CutCornerShape(28)
        Leaf -> RoundedCornerShape(
            topStartPercent = 45, topEndPercent = 8, bottomEndPercent = 45, bottomStartPercent = 8,
        )
    }
}
