package com.example.focuslauncher

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val MAX_SLOTS = 10          // slots per home page
const val PAGES = 2
const val TOTAL_SLOTS = MAX_SLOTS * PAGES

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)
    private val prefs = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var query by mutableStateOf("")
    var theme by mutableStateOf(
        runCatching { LauncherTheme.valueOf(prefs.getString("theme", "")!!) }
            .getOrDefault(LauncherTheme.Midnight)
    )
        private set

    var note by mutableStateOf(
        prefs.getString("note", "If found, please contact: (add number)")!!
    )
        private set
    var welcomeDone by mutableStateOf(false)

    fun saveNote(n: String) {
        note = n
        prefs.edit().putString("note", n).apply()
    }

    var usage by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var tiles by mutableStateOf(prefs.getBoolean("tiles", true))
        private set

    private fun loadTileColors(): Map<String, Int> =
        prefs.getString("tileColors", "")!!.split(";").mapNotNull {
            val kv = it.split("=")
            if (kv.size == 2) kv[1].toIntOrNull()?.let { c -> kv[0] to c } else null
        }.toMap()

    /** Colours the user picked per app (package -> ARGB). Missing = automatic. */
    var tileColors by mutableStateOf(loadTileColors())
        private set

    fun setTileColor(pkg: String, argb: Int?) {
        tileColors = if (argb == null) tileColors - pkg else tileColors + (pkg to argb)
        prefs.edit().putString(
            "tileColors", tileColors.entries.joinToString(";") { "${it.key}=${it.value}" }
        ).apply()
    }

    var shape by mutableStateOf(
        runCatching { IconShape.valueOf(prefs.getString("shape", "")!!) }.getOrDefault(IconShape.Rounded)
    )
        private set

    fun setShape(s: IconShape) {
        shape = s
        prefs.edit().putString("shape", s.name).apply()
    }

    /** For when you're bored: jump to a different random shape. */
    fun randomShape() = setShape(IconShape.values().filter { it != shape }.random())

    var clockStyle by mutableStateOf(
        runCatching { ClockStyle.valueOf(prefs.getString("clock", "")!!) }.getOrDefault(ClockStyle.Digital)
    )
        private set

    fun setClockStyle(c: ClockStyle) {
        clockStyle = c
        prefs.edit().putString("clock", c.name).apply()
    }

    var font by mutableStateOf(
        runCatching { LauncherFont.valueOf(prefs.getString("font", "")!!) }.getOrDefault(LauncherFont.Default)
    )
        private set

    fun setFont(f: LauncherFont) {
        font = f
        prefs.edit().putString("font", f.name).apply()
    }

    var colorTiles by mutableStateOf(prefs.getBoolean("colorTiles", true))
        private set

    fun setColorTiles(on: Boolean) {
        colorTiles = on
        prefs.edit().putBoolean("colorTiles", on).apply()
    }

    fun setTiles(on: Boolean) {
        tiles = on
        prefs.edit().putBoolean("tiles", on).apply()
    }

    // ---- 10 quick-access slots on the home screen ----
    private fun loadSlots(): List<String?> {
        val raw = prefs.getString("slots", null)
        val list: List<String?> =
            if (raw != null) raw.split(",").map { it.ifEmpty { null } }
            else prefs.getStringSet("favs", emptySet())!!.toList() // migrate old pins
        return (list + List(TOTAL_SLOTS) { null }).take(TOTAL_SLOTS)
    }

    var slots by mutableStateOf(loadSlots())
        private set

    val favorites: Set<String> get() = slots.filterNotNull().toSet()

    private fun saveSlots() {
        prefs.edit().putString("slots", slots.joinToString(",") { it ?: "" }).apply()
    }

    fun setSlot(index: Int, pkg: String?) {
        slots = slots.toMutableList().also { it[index] = pkg }
        saveSlots()
    }

    /** Pin/unpin from the drawer. Returns false if home is full. */
    fun toggleFavorite(pkg: String): Boolean {
        val at = slots.indexOf(pkg)
        if (at >= 0) { setSlot(at, null); return true }
        val free = slots.indexOf(null)
        if (free < 0) return false
        setSlot(free, pkg)
        return true
    }

    // ---------- Weather ----------
    var weather by mutableStateOf<Weather?>(null)
        private set
    var city by mutableStateOf(prefs.getString("wCity", "")!!)
        private set
    var useFahrenheit by mutableStateOf(prefs.getBoolean("wF", false))
        private set
    private var lastWeatherFetch = 0L

    fun setFahrenheit(on: Boolean) {
        useFahrenheit = on
        prefs.edit().putBoolean("wF", on).apply()
        fetchWeather(force = true)
    }

    fun setCity(name: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val hit = WeatherApi.geocode(name)
            if (hit == null) {
                withContext(Dispatchers.Main) { onDone(false) }
                return@launch
            }
            prefs.edit()
                .putString("wCity", hit.name)
                .putString("wLat", hit.lat.toString())
                .putString("wLon", hit.lon.toString())
                .apply()
            city = hit.name
            fetchWeatherNow()
            withContext(Dispatchers.Main) { onDone(true) }
        }
    }

    fun clearCity() {
        prefs.edit().remove("wCity").remove("wLat").remove("wLon").apply()
        city = ""
        weather = null
    }

    fun fetchWeather(force: Boolean = false) {
        if (city.isEmpty()) return
        if (!force && System.currentTimeMillis() - lastWeatherFetch < 20 * 60_000L) return
        viewModelScope.launch(Dispatchers.IO) { fetchWeatherNow() }
    }

    private fun fetchWeatherNow() {
        val lat = prefs.getString("wLat", null)?.toDoubleOrNull() ?: return
        val lon = prefs.getString("wLon", null)?.toDoubleOrNull() ?: return
        lastWeatherFetch = System.currentTimeMillis()
        WeatherApi.fetch(lat, lon, useFahrenheit)?.let { weather = it.copy(city = city) }
    }

    // ---------- Focus mode ----------
    var blocked by mutableStateOf(prefs.getStringSet("blocked", emptySet())!!.toSet())
        private set
    var focusUntil by mutableStateOf(prefs.getLong("focusUntil", 0L))
        private set
    var nowMs by mutableStateOf(System.currentTimeMillis())
        private set

    val focusOn: Boolean get() = focusUntil > nowMs

    fun tick() { nowMs = System.currentTimeMillis() }

    fun isHidden(pkg: String) = focusOn && pkg in blocked

    fun setBlocked(set: Set<String>) {
        blocked = set
        prefs.edit().putStringSet("blocked", set).apply()
    }

    fun startFocus(minutes: Int?) {
        nowMs = System.currentTimeMillis()
        focusUntil = if (minutes == null) Long.MAX_VALUE else nowMs + minutes * 60_000L
        prefs.edit().putLong("focusUntil", focusUntil).apply()
    }

    fun stopFocus() {
        focusUntil = 0L
        prefs.edit().putLong("focusUntil", 0L).apply()
    }

    private fun clock(ms: Long) = java.time.Instant.ofEpochMilli(ms)
        .atZone(java.time.ZoneId.systemDefault())
        .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))

    fun focusUntilShort() = if (focusUntil == Long.MAX_VALUE) "on" else "until " + clock(focusUntil)
    fun focusUntilText() = if (focusUntil == Long.MAX_VALUE) "until you turn it off" else "until " + clock(focusUntil)

    // ---------- Search bar ----------
    var showSearchBar by mutableStateOf(prefs.getBoolean("searchBar", true))
        private set
    var searchEngine by mutableStateOf(
        runCatching { SearchEngine.valueOf(prefs.getString("engine", "")!!) }.getOrDefault(SearchEngine.Google)
    )
        private set

    fun setSearchBar(on: Boolean) {
        showSearchBar = on
        prefs.edit().putBoolean("searchBar", on).apply()
    }

    fun setSearchEngine(e: SearchEngine) {
        searchEngine = e
        prefs.edit().putString("engine", e.name).apply()
    }

    // ---------- Gestures ----------
    var swipeDownNotifications by mutableStateOf(prefs.getBoolean("swipeDown", true))
        private set

    fun setSwipeDown(on: Boolean) {
        swipeDownNotifications = on
        prefs.edit().putBoolean("swipeDown", on).apply()
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = repo.loadApps()
            apps = list
            usage = UsageHelper.todayShare(getApplication(), list.map { it.packageName }.toSet())
            fetchWeather()
        }
    }

    fun setTheme(t: LauncherTheme) {
        theme = t
        prefs.edit().putString("theme", t.name).apply()
    }

}
