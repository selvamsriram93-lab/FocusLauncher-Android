package com.example.focuslauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val QUOTES = listOf(
    "Small steps, steady days.",
    "Do one thing well, then the next.",
    "Calm is a kind of progress.",
    "Begin where you are.",
    "Make today a little lighter.",
)

/** Cosmetic greeting shown when the launcher starts. It is NOT a security lock. */
@Composable
fun WelcomeScreen(theme: LauncherTheme, onDismiss: () -> Unit) {
    val now = remember { LocalDateTime.now() }
    val greeting = when (now.hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Good night"
    }
    val quote = remember { QUOTES.random() }

    LaunchedEffect(Unit) { delay(6000); onDismiss() } // auto-dismiss

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(theme.top, theme.bottom)))
            .clickable { onDismiss() }
            .systemBarsPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            now.format(DateTimeFormatter.ofPattern("HH:mm")),
            color = theme.text, fontSize = 88.sp, fontWeight = FontWeight.Thin,
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            color = theme.accent, fontSize = 18.sp,
        )
        Spacer(Modifier.height(48.dp))
        Text(greeting, color = theme.text, fontSize = 28.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        Text(quote, color = theme.text.copy(alpha = 0.7f), fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(64.dp))
        Text("Tap to continue", color = theme.text.copy(alpha = 0.45f), fontSize = 12.sp)
    }
}
