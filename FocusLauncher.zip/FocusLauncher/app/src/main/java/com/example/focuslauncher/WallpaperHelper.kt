package com.example.focuslauncher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

enum class WallpaperStyle(val label: String) {
    Glow("Gradient with glow"),
    Plain("Plain gradient"),
    Solid("Solid colour"),
    Waves("Waves (new each time)"),
    Aurora("Aurora (new each time)"),
    Photo("Photo from gallery"),
}

enum class WallpaperTarget(val label: String, val flags: Int) {
    Both("Home + lock screen", WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK),
    Home("Home screen only", WallpaperManager.FLAG_SYSTEM),
    Lock("Lock screen only", WallpaperManager.FLAG_LOCK),
}

object WallpaperHelper {

    fun render(ctx: Context, theme: LauncherTheme, style: WallpaperStyle): Bitmap {
        val m = ctx.resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rnd = Random(System.nanoTime())

        fun gradient() {
            val p = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, 0f, h.toFloat(),
                    theme.top.toArgb(), theme.bottom.toArgb(), Shader.TileMode.CLAMP,
                )
            }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }

        fun blob(cx: Float, cy: Float, radius: Float, color: Int, alpha: Float) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    cx, cy, radius,
                    ColorUtils.setAlphaComponent(color, (alpha * 255).toInt()),
                    Color.Transparent.toArgb(), Shader.TileMode.CLAMP,
                )
            }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }

        when (style) {
            WallpaperStyle.Glow -> {
                gradient()
                blob(w * 0.85f, h * 0.12f, w * 0.8f, theme.accent.toArgb(), 0.28f)
            }
            WallpaperStyle.Plain, WallpaperStyle.Photo -> gradient()
            WallpaperStyle.Solid -> c.drawColor(theme.top.toArgb())
            WallpaperStyle.Waves -> {
                gradient()
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                for (i in 0 until 5) {
                    val base = h * (0.42f + i * 0.12f)
                    val amp = h * (0.02f + rnd.nextFloat() * 0.03f)
                    val phase = rnd.nextFloat() * 6.28f
                    val freq = 1f + rnd.nextFloat() * 1.5f
                    val path = Path().apply {
                        moveTo(0f, h.toFloat())
                        lineTo(0f, base)
                        var x = 0f
                        while (x <= w) {
                            lineTo(x, base + amp * sin(2 * PI * freq * x / w + phase).toFloat())
                            x += 12f
                        }
                        lineTo(w.toFloat(), h.toFloat())
                        close()
                    }
                    paint.color = ColorUtils.setAlphaComponent(theme.accent.toArgb(), ((0.08f + i * 0.04f) * 255).toInt())
                    c.drawPath(path, paint)
                }
            }
            WallpaperStyle.Aurora -> {
                gradient()
                val second = ColorUtils.blendARGB(theme.accent.toArgb(), theme.text.toArgb(), 0.5f)
                for (i in 0 until 4) {
                    blob(
                        rnd.nextFloat() * w, rnd.nextFloat() * h * 0.8f,
                        w * (0.5f + rnd.nextFloat() * 0.4f),
                        if (i % 2 == 0) theme.accent.toArgb() else second,
                        0.32f,
                    )
                }
            }
        }
        return bmp
    }

    /** Loads a gallery photo and centre-crops it to the screen shape. */
    fun fromUri(ctx: Context, uri: Uri): Bitmap? = runCatching {
        val m = ctx.resources.displayMetrics
        val tw = m.widthPixels
        val th = m.heightPixels

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= tw && bounds.outHeight / (sample * 2) >= th) sample *= 2

        val src = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null

        val scale = maxOf(tw / src.width.toFloat(), th / src.height.toFloat())
        val sw = (src.width * scale).toInt().coerceAtLeast(tw)
        val sh = (src.height * scale).toInt().coerceAtLeast(th)
        val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
        Bitmap.createBitmap(scaled, (sw - tw) / 2, (sh - th) / 2, tw, th)
    }.getOrNull()

    fun apply(ctx: Context, bmp: Bitmap, target: WallpaperTarget): Boolean = runCatching {
        WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, target.flags)
        true
    }.getOrDefault(false)
}
