package com.example.focuslauncher

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Page { Main, Theme, Shape, Clock, Font, Wallpaper, Focus, Engine }

@Composable
fun LauncherSettings(vm: LauncherViewModel, onDismiss: () -> Unit) {
    var page by remember { mutableStateOf(Page.Main) }
    val back = { page = Page.Main }

    when (page) {
        Page.Main -> MainSettings(vm, onDismiss) { page = it }

        Page.Theme -> ChoiceDialog(
            title = "Theme", options = LauncherTheme.values().toList(), selected = vm.theme,
            label = { it.label }, onPick = { vm.updateTheme(it) }, onBack = back,
            preview = { Box(Modifier.size(22.dp).clip(CircleShape).background(it.accent)) },
        )

        Page.Shape -> ChoiceDialog(
            title = "Icon shape", options = IconShape.values().toList(), selected = vm.shape,
            label = { it.label }, onPick = { vm.updateShape(it) }, onBack = back,
            preview = { Box(Modifier.size(22.dp).clip(it.chip()).background(vm.theme.accent)) },
            extra = { TextButton(onClick = { vm.randomShape() }) { Text("Surprise me (random shape)") } },
        )

        Page.Clock -> ChoiceDialog(
            title = "Clock widget", options = ClockStyle.values().toList(), selected = vm.clockStyle,
            label = { it.label }, onPick = { vm.updateClockStyle(it) }, onBack = back,
        )

        Page.Font -> ChoiceDialog(
            title = "Font", options = LauncherFont.values().toList(), selected = vm.font,
            label = { it.label }, onPick = { vm.updateFont(it) }, onBack = back,
            preview = { Text("Aa", fontFamily = it.family, fontSize = 20.sp, modifier = Modifier.width(34.dp)) },
        )

        Page.Wallpaper -> WallpaperDialog(vm, back)
        Page.Focus -> FocusDialog(vm, back)
        Page.Engine -> ChoiceDialog(
            title = "Search engine", options = SearchEngine.values().toList(), selected = vm.searchEngine,
            label = { it.label }, onPick = { vm.updateSearchEngine(it) }, onBack = back,
        )
    }
}

@Composable
private fun MainSettings(vm: LauncherViewModel, onDismiss: () -> Unit, go: (Page) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        title = { Text("Launcher settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SettingRow("Theme", vm.theme.label) { go(Page.Theme) }
                SettingRow("Icon shape", vm.shape.label) { go(Page.Shape) }
                SettingRow("Clock widget", vm.clockStyle.label) { go(Page.Clock) }
                SettingRow("Font", vm.font.label) { go(Page.Font) }
                SettingRow("Wallpaper", "Change") { go(Page.Wallpaper) }
                SettingRow("Focus mode", if (vm.focusOn) "On" else "Off") { go(Page.Focus) }
                SettingRow("Search bar on home", if (vm.showSearchBar) "On" else "Off") { vm.setSearchBar(!vm.showSearchBar) }
                SettingRow("Search engine", vm.searchEngine.label) { go(Page.Engine) }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                SettingRow("Tile colours", if (vm.colorTiles) "Each app" else "Theme") { vm.updateColorTiles(!vm.colorTiles) }
                SettingRow("Layout", if (vm.tiles) "Tiles" else "Icon grid") { vm.updateTiles(!vm.tiles) }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                SettingRow("Swipe down: notifications", if (vm.swipeDownNotifications) "On" else "Off") {
                    vm.setSwipeDown(!vm.swipeDownNotifications)
                }
            }
        },
    )
}

@Composable
private fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, Modifier.weight(1f))
        Text(value, color = MaterialTheme.colorScheme.primary)
        Text("  \u203A")
    }
}

@Composable
private fun <T> ChoiceDialog(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onPick: (T) -> Unit,
    onBack: () -> Unit,
    extra: (@Composable () -> Unit)? = null,
    preview: @Composable (T) -> Unit = {},
) {
    AlertDialog(
        onDismissRequest = onBack,
        confirmButton = { TextButton(onClick = onBack) { Text("Back") } },
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(opt) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        preview(opt)
                        Spacer(Modifier.width(12.dp))
                        Text(label(opt) + if (opt == selected) "  \u2713" else "")
                    }
                }
                extra?.invoke()
            }
        },
    )
}

@Composable
private fun WallpaperDialog(vm: LauncherViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var style by remember { mutableStateOf(WallpaperStyle.Glow) }
    var target by remember { mutableStateOf(WallpaperTarget.Both) }

    fun report(ok: Boolean) {
        Toast.makeText(ctx, if (ok) "Wallpaper set" else "Couldn't set wallpaper", Toast.LENGTH_SHORT).show()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                WallpaperHelper.fromUri(ctx, uri)?.let { WallpaperHelper.apply(ctx, it, target) } ?: false
            }
            report(ok)
        }
    }

    AlertDialog(
        onDismissRequest = onBack,
        dismissButton = { TextButton(onClick = onBack) { Text("Back") } },
        confirmButton = {
            TextButton(onClick = {
                if (style == WallpaperStyle.Photo) picker.launch("image/*")
                else scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        WallpaperHelper.apply(ctx, WallpaperHelper.render(ctx, vm.theme, style), target)
                    }
                    report(ok)
                }
            }) { Text(if (style == WallpaperStyle.Photo) "Choose photo" else "Apply") }
        },
        title = { Text("Wallpaper") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Style", style = MaterialTheme.typography.labelLarge)
                WallpaperStyle.values().forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth().clickable { style = opt }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = style == opt, onClick = { style = opt })
                        Text(opt.label)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("Apply to", style = MaterialTheme.typography.labelLarge)
                WallpaperTarget.values().forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth().clickable { target = opt }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = target == opt, onClick = { target = opt })
                        Text(opt.label)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Colours follow your current theme. Waves and Aurora look different every time you apply.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
    )
}

@Composable
fun FocusDialog(vm: LauncherViewModel, onDismiss: () -> Unit) {
    var minutes by remember { mutableStateOf<Int?>(30) }
    var picking by remember { mutableStateOf(false) }

    if (picking) {
        AppMultiPickerDialog(vm) { picking = false }
        return
    }

    val options: List<Pair<Int?, String>> = listOf(
        15 to "15 minutes", 30 to "30 minutes", 60 to "1 hour", 120 to "2 hours",
        null to "Until I turn it off",
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        confirmButton = {
            if (vm.focusOn) {
                TextButton(onClick = { vm.stopFocus(); onDismiss() }) { Text("Stop focus") }
            } else {
                TextButton(enabled = vm.blocked.isNotEmpty(), onClick = { vm.startFocus(minutes); onDismiss() }) {
                    Text("Start focus")
                }
            }
        },
        title = { Text("Focus mode") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (vm.focusOn) {
                    Text("Focus is on ${vm.focusUntilText()}.")
                    Spacer(Modifier.height(6.dp))
                    Text("${vm.blocked.size} apps are hidden from home and the drawer.")
                } else {
                    Text(
                        "Hides the apps you choose from home and the app drawer until the time is up.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    options.forEach { (m, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { minutes = m }.padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = minutes == m, onClick = { minutes = m })
                            Text(label)
                        }
                    }
                    TextButton(onClick = { picking = true }) { Text("Distracting apps (${vm.blocked.size})") }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Hidden only inside this launcher. Apps can still open from notifications or other launchers.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
    )
}

@Composable
private fun AppMultiPickerDialog(vm: LauncherViewModel, onDone: () -> Unit) {
    var chosen by remember { mutableStateOf(vm.blocked) }
    var q by remember { mutableStateOf("") }
    val list = vm.apps.filter { it.label.contains(q, ignoreCase = true) }

    AlertDialog(
        onDismissRequest = onDone,
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel") } },
        confirmButton = { TextButton(onClick = { vm.updateBlocked(chosen); onDone() }) { Text("Save") } },
        title = { Text("Distracting apps") },
        text = {
            Column {
                OutlinedTextField(
                    value = q, onValueChange = { q = it },
                    singleLine = true, placeholder = { Text("Search") },
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(list, key = { it.packageName }) { app ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    chosen = if (app.packageName in chosen) chosen - app.packageName
                                    else chosen + app.packageName
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = app.packageName in chosen, onCheckedChange = null)
                            Spacer(Modifier.width(8.dp))
                            Text(app.label)
                        }
                    }
                }
            }
        },
    )
}
