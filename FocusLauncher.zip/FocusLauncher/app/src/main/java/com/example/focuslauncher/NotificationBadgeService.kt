package com.example.focuslauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Watches the notification shade so the launcher can show a badge on apps
 * (WhatsApp, Messages, ...) that have notifications you haven't dismissed.
 * Needs the user to enable "Notification access" for this app.
 */
class NotificationBadgeService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()
    override fun onListenerDisconnected() { BadgeStore.counts = emptyMap() }
    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()

    private fun refresh() {
        val active = runCatching { activeNotifications }.getOrNull() ?: return
        val relevant = active.filter {
            it.packageName != packageName &&
                it.notification.flags and Notification.FLAG_ONGOING_EVENT == 0
        }
        BadgeStore.counts = relevant.groupBy { it.packageName }.mapValues { (_, list) ->
            val children = list.count { it.notification.flags and Notification.FLAG_GROUP_SUMMARY == 0 }
            if (children > 0) children else 1 // app only posted a summary
        }
    }
}
