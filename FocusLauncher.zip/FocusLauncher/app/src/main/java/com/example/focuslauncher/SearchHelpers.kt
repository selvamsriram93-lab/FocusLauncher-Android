package com.example.focuslauncher

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.pow

/** Tiny calculator for the search box: "12*(3+4)", "2^10", "100/8". */
object Calc {
    fun eval(input: String): Double? {
        val s = input.replace(" ", "").replace("\u00D7", "*").replace("\u00F7", "/")
        if (s.length < 3) return null
        if (!s.any { it in "+-*/^%" }) return null
        if (!s.all { it.isDigit() || it in "+-*/^().%" }) return null
        return runCatching { Parser(s).parse() }.getOrNull()?.takeIf { it.isFinite() }
    }

    fun format(v: Double): String =
        BigDecimal(v).round(MathContext(10)).stripTrailingZeros().toPlainString()

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); check(i == s.length); return v }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]; val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i++]; val r = power()
                v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return b.pow(power()) }
            return b
        }
        fun unary(): Double {
            if (s[i] == '-') { i++; return -unary() }
            if (s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (s[i] == '(') {
                i++; val v = expr()
                check(i < s.length && s[i] == ')'); i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            check(i > st)
            return s.substring(st, i).toDouble()
        }
    }
}

