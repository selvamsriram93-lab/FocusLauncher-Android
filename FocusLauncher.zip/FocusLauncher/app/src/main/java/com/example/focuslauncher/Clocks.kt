package com.example.focuslauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

enum class ClockStyle(val label: String) {
    Digital("Digital"),
    Stacked("Big stacked"),
    Analog("Analog"),
    Words("Words"),
    DateCard("Date card"),
}

private fun fmt(now: LocalDateTime, pattern: String) = now.format(DateTimeFormatter.ofPattern(pattern))

/** Clock widget shown in the top 30% of the home screen. */
@Composable
fun ClockWidget(style: ClockStyle, now: LocalDateTime, theme: LauncherTheme) {
    Box(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        when (style) {
            ClockStyle.Digital -> Column {
                Text(fmt(now, "HH:mm"), color = theme.text, fontSize = 68.sp, fontWeight = FontWeight.Light)
                Text(fmt(now, "EEEE, d MMMM"), color = theme.accent, fontSize = 16.sp)
            }

            ClockStyle.Stacked -> Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(fmt(now, "HH"), color = theme.text, fontSize = 56.sp, lineHeight = 56.sp, fontWeight = FontWeight.Light)
                    Text(fmt(now, "mm"), color = theme.accent, fontSize = 56.sp, lineHeight = 56.sp, fontWeight = FontWeight.Light)
                }
                Spacer(Modifier.width(24.dp))
                Column {
                    Text(fmt(now, "EEEE"), color = theme.text, fontSize = 20.sp)
                    Text(fmt(now, "d MMMM"), color = theme.text.copy(alpha = 0.6f), fontSize = 14.sp)
                }
            }

            ClockStyle.Analog -> Row(verticalAlignment = Alignment.CenterVertically) {
                AnalogFace(now, theme, Modifier.size(140.dp))
                Spacer(Modifier.width(24.dp))
                Column {
                    Text(fmt(now, "HH:mm"), color = theme.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
                    Text(fmt(now, "EEEE"), color = theme.accent, fontSize = 16.sp)
                    Text(fmt(now, "d MMMM"), color = theme.text.copy(alpha = 0.6f), fontSize = 14.sp)
                }
            }

            ClockStyle.Words -> {
                val (top, bottom) = wordsFor(now)
                Column {
                    Text(top, color = theme.accent, fontSize = 22.sp)
                    Text(bottom, color = theme.text, fontSize = 44.sp, lineHeight = 48.sp, fontWeight = FontWeight.Light)
                    Text(fmt(now, "EEEE, d MMMM"), color = theme.text.copy(alpha = 0.6f), fontSize = 14.sp)
                }
            }

            ClockStyle.DateCard -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmt(now, "dd"), color = theme.accent, fontSize = 84.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.width(18.dp))
                Column {
                    Text(fmt(now, "EEEE"), color = theme.text, fontSize = 22.sp)
                    Text(fmt(now, "MMMM yyyy"), color = theme.text.copy(alpha = 0.6f), fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(fmt(now, "HH:mm"), color = theme.text, fontSize = 20.sp, fontWeight = FontWeight.Light)
                }
            }
        }
    }
}

@Composable
private fun AnalogFace(now: LocalDateTime, theme: LauncherTheme, modifier: Modifier) {
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2 - 4.dp.toPx()

        drawCircle(theme.text.copy(alpha = 0.25f), r, c, style = Stroke(2.dp.toPx()))
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val inner = if (i % 3 == 0) r * 0.82f else r * 0.9f
            drawLine(
                theme.text.copy(alpha = if (i % 3 == 0) 0.8f else 0.4f),
                Offset(c.x + inner * sin(a).toFloat(), c.y - inner * cos(a).toFloat()),
                Offset(c.x + r * 0.96f * sin(a).toFloat(), c.y - r * 0.96f * cos(a).toFloat()),
                strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
            )
        }

        val minute = now.minute + now.second / 60f
        val hourAngle = Math.toRadians((((now.hour % 12) + minute / 60f) * 30f).toDouble())
        val minAngle = Math.toRadians((minute * 6f).toDouble())

        drawLine(
            theme.text, c,
            Offset(c.x + r * 0.5f * sin(hourAngle).toFloat(), c.y - r * 0.5f * cos(hourAngle).toFloat()),
            strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round,
        )
        drawLine(
            theme.accent, c,
            Offset(c.x + r * 0.75f * sin(minAngle).toFloat(), c.y - r * 0.75f * cos(minAngle).toFloat()),
            strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round,
        )
        drawCircle(theme.accent, 5.dp.toPx(), c)
    }
}

private val HOUR_WORDS = listOf(
    "twelve", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten", "eleven",
)
private val PAST = mapOf(5 to "five past", 10 to "ten past", 15 to "quarter past", 20 to "twenty past", 25 to "twenty-five past", 30 to "half past")
private val TO = mapOf(5 to "five to", 10 to "ten to", 15 to "quarter to", 20 to "twenty to", 25 to "twenty-five to")

/** "quarter past" / "nine" style split of the time, rounded to 5 minutes. */
private fun wordsFor(now: LocalDateTime): Pair<String, String> {
    var hour = now.hour
    var min = ((now.minute + 2) / 5) * 5
    if (min == 60) { min = 0; hour += 1 }
    return when {
        min == 0 -> "it's" to "${HOUR_WORDS[hour % 12]} o'clock"
        min <= 30 -> PAST.getValue(min) to HOUR_WORDS[hour % 12]
        else -> TO.getValue(60 - min) to HOUR_WORDS[(hour + 1) % 12]
    }
}
