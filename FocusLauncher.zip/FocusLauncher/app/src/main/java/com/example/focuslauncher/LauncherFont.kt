package com.example.focuslauncher

import android.graphics.Typeface
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * Fonts you can pick in Settings. The first six come with every Android phone;
 * the last four are bundled in res/font (all open-licence fonts from Google Fonts).
 */
enum class LauncherFont(val label: String, val family: FontFamily) {
    Default("System default", FontFamily.Default),
    Light("Light", FontFamily(Typeface.create("sans-serif-light", Typeface.NORMAL))),
    Condensed("Condensed", FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))),
    Serif("Serif", FontFamily.Serif),
    Mono("Monospace", FontFamily.Monospace),
    Handwriting("Handwriting", FontFamily.Cursive),
    Poppins(
        "Poppins (modern)",
        FontFamily(
            Font(R.font.poppins_light, FontWeight.Light),
            Font(R.font.poppins_regular, FontWeight.Normal),
            Font(R.font.poppins_medium, FontWeight.Medium),
        ),
    ),
    SpaceMono(
        "Space Mono (techy)",
        FontFamily(
            Font(R.font.spacemono_regular, FontWeight.Normal),
            Font(R.font.spacemono_bold, FontWeight.Bold),
        ),
    ),
    Bebas("Bebas Neue (tall caps)", FontFamily(Font(R.font.bebasneue_regular, FontWeight.Normal))),
    Pacifico("Pacifico (brush script)", FontFamily(Font(R.font.pacifico_regular, FontWeight.Normal))),
}
