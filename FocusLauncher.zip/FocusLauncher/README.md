# Focus Launcher (starter)

Kotlin + Jetpack Compose home-screen launcher with switchable themes.

## Run it
1. Install Android Studio (Koala or newer).
2. File > Open > select this `FocusLauncher` folder. Let Gradle sync
   (it creates the Gradle wrapper automatically).
3. Run on a device/emulator (API 26+).
4. Press the Home button; Android asks which launcher to use. Pick "Focus Launcher".
   To switch back: Settings > Apps > Default apps > Home app.

## Features
- Clock + date, themed gradient background
- Swipe up (or tap "All apps") for searchable app grid
- Long-press an app: pin to home / app info & uninstall
- Long-press the home background: choose theme
- Refreshes automatically when apps are installed/removed

## Customize
- Themes: `Theme.kt`
- Home layout: `HomeScreen` in `LauncherScreen.kt`
- App loading/filtering: `AppRepository.kt`

## New: lock screen extras
1. **Matching wallpaper** - Long-press home > "Set theme as home + lock wallpaper".
   Ready-made PNGs are also in `wallpapers/` if you prefer to set them manually.
2. **Welcome screen** - shown when the launcher starts (tap to dismiss, auto-closes in 6 s).
   Cosmetic only; it is not a security lock.
3. **Lock-screen card** - Long-press home > "Edit lock-screen card". Posts a notification
   readable on the lock screen. Needs notification permission, and your phone's setting
   "Lock screen > Notifications" must allow showing content. Do not store private data.

## Unread badges
Apps with notifications you haven't dismissed (WhatsApp, Messages, ...) get a red count badge
in the app drawer, and pinned apps on home turn bold with a badge.
Enable once: Long-press home > "Turn on unread badges" > allow "Focus Launcher".
The count is the number of notifications in the shade, so it drops when you clear them.

## Tile layout (default)
The app drawer shows minimal tiles: grey icon, app name, a bordered unread count (needs the
unread-badges permission) and today's share of screen time (needs "Usage access").
Long-press home > Settings to switch between tiles and the classic icon grid.

## Home screen: 10 quick-access slots
The home page has 10 tiles (2 x 5). Tap a "+" to pick an app. Long-press a filled tile to
replace or remove it. Long-pressing an app in the drawer and choosing "Pin to home" fills the
first free slot. Unread counts and usage % show on these tiles too.

## Colourful tiles
Each tile takes its own colour from the app's icon (WhatsApp green, Gmail red, ...). Apps with
grey/white icons get a colour from a fixed palette, so it stays the same every time.
Long-press home > Settings > "Tile colours" switches to calm theme-tinted tiles.

## Choose a tile's colour
Long-press a tile on home > "Change colour" (or long-press an app in the drawer > "Tile colour").
Pick one of 12 colours, or "Auto (from icon)" to reset. Choices are saved per app.

## Icon shapes
Long-press home > Settings > "Icon shape": Rounded, Soft squircle, Extra round / circle,
Sharp square, Cut corners, Leaf. "Surprise me" jumps to a random one when you're bored.
The shape applies to tiles, their icon chips, empty slots and the classic icon grid.

## Home layout, clock widgets, fonts, wallpapers
- Home: top 30% = clock widget, bottom 70% = apps (10 slots + "All apps").
- Settings > Clock widget: Digital, Big stacked, Analog, Words, Date card.
- Settings > Font: 6 system fonts + Poppins, Space Mono, Bebas Neue, Pacifico (bundled in
  res/font; open-licence fonts from Google Fonts, SIL OFL).
- Settings > Wallpaper: gradient with glow, plain gradient, solid, waves, aurora, or a photo from
  your gallery; apply to home, lock, or both. Colours follow the current theme.

## Weather, battery, focus, gestures, search
- Home page 1: clock (top 30%) with a line for weather, battery and a Focus chip; 10 app slots below.
- Swipe left: home page 2 with big weather + battery cards and 10 more slots.
- Weather: Settings > Weather > type a city (needs internet; open-meteo.com, no account).
- Battery: live level, charging bolt, turns red at 15% or less.
- Focus mode: Settings > Focus mode (or tap the Focus chip). Choose distracting apps and a time;
  they are hidden from home and the drawer until it ends.
- Gestures: double-tap = lock screen (Settings > Double-tap to lock; uses Android "device admin",
  force-lock only), swipe down = notifications (hidden Android call; may not work on all phones),
  swipe up = app drawer, long-press = settings.
- Search (app drawer): calculator ("12*(3+4)"), contacts (asks permission; tap opens the dialer),
  and "Search the web".

## Search bar on home
A pill-shaped search bar sits at the bottom of the home screen. Tap it, type, press search:
the query opens in your browser (typing an address such as example.com opens that site).
The mic icon starts Google voice search if your phone has it. Settings > "Search bar on home"
hides it; Settings > "Search engine" switches between Google, DuckDuckGo, Bing and Brave.


## Privacy-focused build notes

This build disables Android cloud backup for launcher app data and blocks cleartext HTTP traffic.
The project includes no advertising, analytics, or crash-reporting SDKs in its Gradle dependencies.

### Data and permissions
- App preferences, pinned apps, focus-mode choices, theme, and weather city are stored locally.
- Contacts are searched on-device after you grant Contacts permission. The app does not upload your contacts.
- Notification access reads active notification metadata locally to calculate unread badges. Notification contents are not sent to a server by this project.
- Device-admin access is used only for the explicit double-tap screen-lock feature.
- Weather requires internet. The city name is sent to Open-Meteo's geocoding service; saved latitude/longitude are sent to Open-Meteo for forecasts. Open-Meteo will also receive normal network connection metadata such as your IP address.
- Web searches open your selected search provider in your browser. Search terms are sent to that provider, not to a Focus Launcher server.

### Reduce data access
You can leave Contacts, Notification access, and Device admin disabled. Their related features will be unavailable, while the basic launcher remains usable. Turn Weather off to avoid weather requests. Avoid putting private information in the lock-screen card because Android may show it on the lock screen.

There is no backend account or Focus Launcher server in this source project. Review the permissions above before enabling optional Android access.


## Privacy-focused revision 1.1
- Removed the Usage Access permission and screen-time percentage feature.
- Weather, contacts search, notification badges, and double-tap screen lock remain available.
- Contacts, notification access, and device-admin access remain optional and require explicit user action in Android settings or a permission prompt.


## Focus Launcher Lite 1.2
This build removes Weather, notification badges, Contacts search, device-admin screen lock, and lock-screen card integration. It does not request INTERNET, READ_CONTACTS, POST_NOTIFICATIONS, or notification-listener/device-admin access. Core home-screen and app-drawer functions remain.


## Focus Launcher Lite 1.2
Removed features: Weather, notification badges, Contacts search, device-admin screen lock, and lock-screen card. The manifest no longer requests INTERNET, READ_CONTACTS, POST_NOTIFICATIONS, notification-listener access, or device-admin access. The app retains its home screen, app drawer, app launching, clock, battery display, themes, wallpapers, and local focus settings.
